### R code from vignette source 'MiClip_vignette.Rnw'

###################################################
### code chunk number 1: MiClip_vignette.Rnw:61-65
###################################################
library("MiClip")

MiClip.adaptor(file="test.fastq",
                adaptor="TGGAATTCTCGGGTGCCAAGGAACTCCAGTCAC")


###################################################
### code chunk number 2: MiClip_vignette.Rnw:104-110
###################################################
library("MiClip")

test=MiClip(file="test.sam")

# for paired-end data
# test=MiClip(file="test.sam",paired=TRUE,suffix=c("F3","F5-RNA"))


###################################################
### code chunk number 3: MiClip_vignette.Rnw:123-124
###################################################
test=MiClip.read(test) # read raw data


###################################################
### code chunk number 4: MiClip_vignette.Rnw:134-135
###################################################
test=MiClip.enriched(test,quiet=FALSE) # identify enriched regions


###################################################
### code chunk number 5: MiClip_vignette.Rnw:146-147
###################################################
test=MiClip.binding(test,quiet=FALSE) # identify binding sites


###################################################
### code chunk number 6: MiClip_vignette.Rnw:162-169
###################################################
enriched=test$enriched # test is a list of 3 components
sites=test$sites
clusters=test$clusters

head(enriched)
head(sites)
head(clusters)


###################################################
### code chunk number 7: MiClip_vignette.Rnw:184-185
###################################################
summary(test)


###################################################
### code chunk number 8: session
###################################################
sessionInfo()


